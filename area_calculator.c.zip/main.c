#include <stdio.h>
#include <math.h>
double calculateRectangleArea(double length, double width) {
    return length * width;
}

double calculateSquareArea(double side) {
    return side * side;
}

double calculateCircleArea(double radius) {
    return M_PI * radius * radius;
}

double calculateTriangleArea(double base, double height) {
    return 0.5 * base * height;
}

double calculateParallelogramArea(double base, double height) {
    return base * height;
}

double calculateTrapezoidArea(double base1, double base2, double height) {
    return 0.5 * (base1 + base2) * height;
}

double calculateEllipseArea(double majorAxis, double minorAxis) {
    return M_PI * majorAxis * minorAxis;
}


int main() {
    int choice;
    
    
        
        printf("\nGeometry Area Calculator\n");
        printf("1. Rectangle\n");
        printf("2. Square\n");
        printf("3. Circle\n");
        printf("4. Triangle\n");
        printf("5. Parallelogram\n");
        printf("6. Trapezoid\n");
        printf("7. Ellipse\n");
        printf("8. Exit\n");
        printf("Enter your choice (1-8): ");
        scanf("%d", &choice);
        
        switch (choice) {
            case 1: // Rectangle
                {
                    double length, width;
                    printf("Enter length: ");
                    scanf("%lf", &length);
                    printf("Enter width: ");
                    scanf("%lf", &width);
                    printf("Area of Rectangle: %.2f\n", calculateRectangleArea(length, width));
                }
                break;
                
            case 2: // Square
                {
                    double side;
                    printf("Enter side length: ");
                    scanf("%lf", &side);
                    printf("Area of Square: %.2f\n", calculateSquareArea(side));
                }
                break;

            case 3: // Circle
                {
                    double radius;
                    printf("Enter radius: ");
                    scanf("%lf", &radius);
                    printf("Area of Circle: %.2f\n", calculateCircleArea(radius));
                }
                break;

            case 4: // Triangle
                {
                    double base, height;
                    printf("Enter base length: ");
                    scanf("%lf", &base);
                    printf("Enter height: ");
                    scanf("%lf", &height);
                    printf("Area of Triangle: %.2f\n", calculateTriangleArea(base, height));
                }
                break;

            case 5: // Parallelogram
                {
                    double base, height;
                    printf("Enter base length: ");
                    scanf("%lf", &base);
                    printf("Enter height: ");
                    scanf("%lf", &height);
                    printf("Area of Parallelogram: %.2f\n", calculateParallelogramArea(base, height));
                }
                break;

            case 6: // Trapezoid
                {
                    double base1, base2, height;
                    printf("Enter length of base 1: ");
                    scanf("%lf", &base1);
                    printf("Enter length of base 2: ");
                    scanf("%lf", &base2);
                    printf("Enter height: ");
                    scanf("%lf", &height);
                    printf("Area of Trapezoid: %.2f\n", calculateTrapezoidArea(base1, base2, height));
                }
                break;

            case 7: // Ellipse
                {
                    double majorAxis, minorAxis;
                    printf("Enter length of major axis: ");
                    scanf("%lf", &majorAxis);
                    printf("Enter length of minor axis: ");
                    scanf("%lf", &minorAxis);
                    printf("Area of Ellipse: %.2f\n", calculateEllipseArea(majorAxis, minorAxis));
                }
                break;

            case 8: // Exit
                printf("Exiting program. Goodbye!\n");
                break;

            default:
                printf("Invalid choice. Please enter a number between 1 and 8.\n");
        }
    

    return 0;
}
